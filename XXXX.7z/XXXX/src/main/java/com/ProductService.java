package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Product;


@Service
public class ProductService {
	
	/*adding  repository usinf autowired*/
	@Autowired
	private ProductRepo productRepo;
	
	@Transactional
  public void add(Product product)
  {
	  productRepo.save(product);
  }
	
}
