package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Product;


public class Test {
 
	public static void main(String[] args) {
		//Create Spring application context
		ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:/myspring-config.xml");
		
		//Get service from context.
		ProductService productService = ctx.getBean(ProductService.class);
		
		//Add some items
		productService.add(new Product(1, "MotoG5"));
		((AbstractApplicationContext) ctx).close();
	}

}
